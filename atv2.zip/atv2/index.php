<!DOCTYPE html>
<html>
<head>
    <title>Formulário de Produto</title>
</head>
<body>
    <h1>Formulário de Produto</h1>
    <form action="processamento.php" method="post">
        <label for="nome">Nome do Produto:</label>
        <input type="text" name="nome" required><br>

        <label for="preco">Preço:</label>
        <input type="number" name="preco" required><br>

        <label for="tipo">Tipo (A, L, V):</label>
        <input type="text" name="tipo" required><br>

        <label for="refrigeracao">Refrigeração (S ou N):</label>
        <input type="text" name="refrigeracao" required><br>

        <input type="submit" value="Calcular">
    </form>
</body>
</html>
