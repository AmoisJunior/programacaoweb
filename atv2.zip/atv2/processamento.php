<!DOCTYPE html>
<html>
<head>
    <title>Resultado</title>
</head>
<body>
    <h1>Resultado</h1>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = $_POST["nome"];
        $preco = floatval($_POST["preco"]);
        $tipo = $_POST["tipo"];
        $refrigeracao = $_POST["refrigeracao"];

        // Calcular o valor adicional
        $adicional = 0;
        if ($tipo == "A" && $refrigeracao == "S") {
            $adicional = 5;
        } elseif ($tipo == "L" && $refrigeracao == "N") {
            $adicional = 2;
        } elseif ($tipo == "V" && $refrigeracao == "S") {
            $adicional = 3;
        }

        // Calcular o imposto
        $imposto = $preco * 0.1;

        // Calcular o preço de custo
        $precoCusto = $preco + $imposto;

        // Calcular o desconto
        $desconto = 0;
        if ($tipo == "A" && $refrigeracao == "S") {
            $desconto = 0.03 * $precoCusto;
        }

        // Calcular o novo preço
        $novoPreco = $precoCusto + $adicional - $desconto;

        // Classificação
        $classificacao = "";
        if ($precoCusto <= 50) {
            $classificacao = "Barato";
        } elseif ($precoCusto <= 100) {
            $classificacao = "Normal";
        } else {
            $classificacao = "Caro";
        }

        // Exibir resultados
        echo "<table border><thead><h1>Tabela de Valor</h1><th>Produto: $nome</th> <th>preço de custo: $precoCusto</th>
              <th>Classificação: $classificacao</th>
              <tbody>
                <tr> <td>Valor Adicional: $adicional</td> <td>Imposto: $imposto</td>
                <td>Desconto: $desconto</td>
                </tr>
                <tr><td><strong>Novo Preço: $novoPreco</strong></td></tr>
              </tbody>
        
        </table>";
    }
    ?>
</body>
</html>
